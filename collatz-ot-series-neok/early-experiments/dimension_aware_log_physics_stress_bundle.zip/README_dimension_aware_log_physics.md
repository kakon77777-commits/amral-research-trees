# Dimension-Aware Logarithmic Physics Stress Test

This experiment tests the additive-coordinate idea on real physics-style formulas.

Core representation:
    Q <-> (sign, dimension-vector, log-magnitude)

The dimension vector uses SI base dimensions:
    (kg, m, s, A, K, mol, cd)

Key legality rule:
    Multiplication/division add/subtract dimension exponents.
    Rational powers scale dimension exponents.
    Addition/subtraction are allowed only when dimensions match.

Benchmarks:
- Sphere volume: (4*pi/3) r^3
- Pendulum period: 2*pi*sqrt(L/g)
- Quantum phase-space cell: (2*pi*hbar)^3 = h^3  [explicit pi^3 cancellation]
- Stefan-Boltzmann constant: 2*pi^5*k_B^4/(15*h^3*c^2)
- Blackbody flux: sigma*T^4
- Relativistic energy: sqrt((pc)^2 + (mc^2)^2) using log-sum-exp
- Lorentz factor near c: (1-beta^2)^(-1/2) using log-diff-exp

The last case deliberately tests severe cancellation with beta=1-1e-40.
Ordinary binary64 cannot even distinguish that beta from 1.0, while the
high-precision log-difference path remains finite and accurate.
