#!/usr/bin/env python3
"""
Dimension-aware logarithmic coordinate physics stress test.

Representation of a nonzero physical quantity Q in coherent SI units:

    Q <-> (sign, d, L)

where
    sign in {-1,+1}
    d is the SI base-dimension exponent vector
    L = ln(|q|)

and q is the numerical coefficient in the fixed coherent SI basis.

Multiplication/division:
    d add/subtract
    L add/subtract

Rational powers:
    d and L are both scaled by the exponent

Addition/subtraction:
    legal only when the dimension vectors agree.
    positive addition uses log-sum-exp
    positive subtraction uses log-diff-exp.

This is an MVP for testing real physics formulas containing powers,
roots, pi^n, extreme scales, and cancellation.
"""

from dataclasses import dataclass
from fractions import Fraction
from typing import Tuple
import mpmath as mp

# SI basis: kg, m, s, A, K, mol, cd
Dim = Tuple[Fraction, Fraction, Fraction, Fraction, Fraction, Fraction, Fraction]
ZERO_DIM: Dim = tuple(Fraction(0) for _ in range(7))  # type: ignore

def D(M=0, L=0, T=0, I=0, Th=0, N=0, J=0) -> Dim:
    return tuple(Fraction(x) for x in (M, L, T, I, Th, N, J))  # type: ignore

def dadd(a: Dim, b: Dim) -> Dim:
    return tuple(x+y for x,y in zip(a,b))  # type: ignore

def dsub(a: Dim, b: Dim) -> Dim:
    return tuple(x-y for x,y in zip(a,b))  # type: ignore

def dscale(a: Dim, p: Fraction) -> Dim:
    return tuple(p*x for x in a)  # type: ignore

@dataclass(frozen=True)
class LQ:
    sign: int
    dim: Dim
    logabs: mp.mpf

    @staticmethod
    def from_value(value, dim: Dim = ZERO_DIM):
        v = mp.mpf(value)
        if v == 0:
            raise ValueError("Zero is not represented in this minimal nonzero log chart.")
        return LQ(1 if v > 0 else -1, dim, mp.log(abs(v)))

    def value(self):
        return self.sign * mp.exp(self.logabs)

    def mul(self, other: "LQ") -> "LQ":
        return LQ(self.sign*other.sign, dadd(self.dim, other.dim),
                  self.logabs + other.logabs)

    def div(self, other: "LQ") -> "LQ":
        return LQ(self.sign*other.sign, dsub(self.dim, other.dim),
                  self.logabs - other.logabs)

    def powq(self, p: Fraction) -> "LQ":
        if self.sign < 0 and p.denominator != 1:
            raise ValueError("Fractional real power of negative quantity not in real chart.")
        if self.sign < 0:
            sign = -1 if p.numerator % 2 else 1
        else:
            sign = 1
        return LQ(sign, dscale(self.dim, p), self.logabs * mp.mpf(p.numerator) / p.denominator)

    def add_positive(self, other: "LQ") -> "LQ":
        if self.dim != other.dim:
            raise ValueError("Dimensional illegality: addition requires equal dimensions.")
        if self.sign <= 0 or other.sign <= 0:
            raise ValueError("This MVP's logsumexp path expects positive operands.")
        a, b = self.logabs, other.logabs
        m = max(a, b)
        return LQ(1, self.dim, m + mp.log(mp.exp(a-m) + mp.exp(b-m)))

    def sub_positive(self, other: "LQ") -> "LQ":
        if self.dim != other.dim:
            raise ValueError("Dimensional illegality: subtraction requires equal dimensions.")
        if self.sign <= 0 or other.sign <= 0:
            raise ValueError("This MVP's logdiffexp path expects positive operands.")
        if self.logabs <= other.logabs:
            raise ValueError("This positive-chart subtraction requires left > right > 0.")
        # log(A-B) = log A + log(1-exp(logB-logA))
        z = mp.exp(other.logabs - self.logabs)
        return LQ(1, self.dim, self.logabs + mp.log1p(-z))

def relerr(a, b):
    a, b = mp.mpf(a), mp.mpf(b)
    return abs(a-b)/abs(b) if b != 0 else abs(a-b)

def fmt(x, n=18):
    return mp.nstr(x, n)

def run(dps=120):
    mp.mp.dps = dps

    # Base dimensions.
    MASS = D(M=1)
    LENGTH = D(L=1)
    TIME = D(T=1)
    TEMP = D(Th=1)
    ENERGY = D(M=1, L=2, T=-2)
    ACTION = D(M=1, L=2, T=-1)
    VELOCITY = D(L=1, T=-1)
    MOMENTUM = D(M=1, L=1, T=-1)

    one = LQ.from_value(1)
    pi = LQ.from_value(mp.pi)

    # Exact SI defining constants used in the tests.
    c = LQ.from_value("299792458", VELOCITY)
    h = LQ.from_value("6.62607015e-34", ACTION)
    kB = LQ.from_value("1.380649e-23", dsub(ENERGY, TEMP))

    rows = []

    # 1) Geometry/physics style cubic structure: sphere volume V=(4π/3)r^3.
    r_num = mp.mpf("0.123456789")
    r = LQ.from_value(r_num, LENGTH)
    V = LQ.from_value(4).mul(pi).div(LQ.from_value(3)).mul(r.powq(Fraction(3)))
    V_ref = mp.mpf(4)/3 * mp.pi * r_num**3
    rows.append(("sphere V=(4π/3)r^3", V, V_ref))

    # 2) Pendulum period T=2π sqrt(L/g).
    ell_num = mp.mpf("0.994")
    g_num = mp.mpf("9.80665")
    ell = LQ.from_value(ell_num, LENGTH)
    g = LQ.from_value(g_num, D(L=1,T=-2))
    pend = LQ.from_value(2).mul(pi).mul(ell.div(g).powq(Fraction(1,2)))
    pend_ref = 2*mp.pi*mp.sqrt(ell_num/g_num)
    rows.append(("pendulum T=2π√(L/g)", pend, pend_ref))

    # 3) Explicit π^3 battlefield: phase-space cell (2π ħ)^3.
    # With ħ=h/(2π), this should reduce to h^3.
    hbar = h.div(LQ.from_value(2).mul(pi))
    cell = LQ.from_value(2).mul(pi).mul(hbar).powq(Fraction(3))
    cell_ref = mp.mpf("6.62607015e-34")**3
    rows.append(("phase cell (2πħ)^3 = h^3", cell, cell_ref))

    # 4) π^5 + fourth/cubic/squared powers:
    # sigma = 2*pi^5*k_B^4 / (15*h^3*c^2)
    sigma = (LQ.from_value(2)
             .mul(pi.powq(Fraction(5)))
             .mul(kB.powq(Fraction(4)))
             .div(LQ.from_value(15))
             .div(h.powq(Fraction(3)))
             .div(c.powq(Fraction(2))))
    sigma_ref = (2*mp.pi**5 * mp.mpf("1.380649e-23")**4 /
                 (15 * mp.mpf("6.62607015e-34")**3 * mp.mpf("299792458")**2))
    rows.append(("Stefan-Boltzmann σ (π^5 form)", sigma, sigma_ref))

    # 5) Blackbody flux j = sigma*T^4 at 5772 K.
    temp_num = mp.mpf("5772")
    temp = LQ.from_value(temp_num, TEMP)
    flux = sigma.mul(temp.powq(Fraction(4)))
    flux_ref = sigma_ref * temp_num**4
    rows.append(("blackbody flux σT^4 @ 5772 K", flux, flux_ref))

    # 6) Relativistic energy:
    # E=sqrt((pc)^2 + (mc^2)^2), using p = 10 m c for an electron.
    me_num = mp.mpf("9.1093837139e-31")
    me = LQ.from_value(me_num, MASS)
    p = LQ.from_value(10).mul(me).mul(c)
    pc_term = p.mul(c)
    mc2_term = me.mul(c.powq(Fraction(2)))
    E = (pc_term.powq(Fraction(2))
         .add_positive(mc2_term.powq(Fraction(2)))
         .powq(Fraction(1,2)))
    E_ref = mp.sqrt((10*me_num*mp.mpf("299792458")**2)**2 +
                    (me_num*mp.mpf("299792458")**2)**2)
    rows.append(("relativistic E=√((pc)^2+(mc²)^2)", E, E_ref))

    # 7) Severe subtraction/cancellation:
    # gamma=(1-beta^2)^(-1/2), beta = 1 - 1e-40.
    beta_num = mp.mpf(1) - mp.mpf("1e-40")
    beta = LQ.from_value(beta_num)
    beta2 = beta.powq(Fraction(2))
    one_minus_beta2 = one.sub_positive(beta2)
    gamma = one_minus_beta2.powq(Fraction(-1,2))
    gamma_ref = 1/mp.sqrt(1-beta_num**2)
    rows.append(("Lorentz γ, β=1−10^-40", gamma, gamma_ref))

    # Illegal-dimensional addition test.
    illegal_ok = False
    try:
        _ = r.add_positive(temp)
    except ValueError:
        illegal_ok = True

    print("Dimension-aware logarithmic physics stress test")
    print("="*88)
    print(f"working precision: {dps} decimal digits")
    print()
    for name, q, ref in rows:
        got = q.value()
        print(name)
        print("  dimension =", tuple(str(x) for x in q.dim))
        print("  log-coordinate result =", fmt(got, 28))
        print("  direct high-precision =", fmt(ref, 28))
        print("  relative error =", fmt(relerr(got, ref), 8))
        print()

    # Compare sigma to the displayed NIST concise leading digits.
    nist_sigma_leading = mp.mpf("5.670374419e-8")
    print("Stefan-Boltzmann check against NIST displayed leading digits")
    print("  computed sigma =", fmt(sigma.value(), 30))
    print("  NIST leading   =", fmt(nist_sigma_leading, 15))
    print("  leading-digit difference =", fmt(sigma.value()-nist_sigma_leading, 12))
    print()
    print("Dimensional-illegality test (meter + kelvin rejected):", illegal_ok)
    print()
    # Show the cancellation stress versus ordinary binary64 input.
    beta_float = 1.0 - 1e-40
    print("Cancellation stress:")
    print("  high-precision beta differs from 1:", beta_num != 1)
    print("  binary64 beta = 1.0 - 1e-40 ->", repr(beta_float))
    print("  gamma (log-diff path) =", fmt(gamma.value(), 30))

if __name__ == "__main__":
    run()
