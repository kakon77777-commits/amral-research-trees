# Collatz operation-translation finite verification prototype

Domain: 1 <= n < 2^20 = 1,048,576

Map:
- even: n -> n/2
- odd: n -> (3n+1)/2

Exact block identity for residue r mod 2^k:

T^k(r + a*2^k) = T^k(r) + a*3^s

where s is the number of odd steps among the first k modified-Collatz steps.

Best tested k: 16
Baseline primitive steps: 3,653,717
Hybrid fallback primitive steps: 1,272,409
Primitive-step reduction: 65.175%
Bulk-certified values: 938,413/1,048,575 = 89.494%

This is a finite-range verification accelerator, not a proof of the Collatz conjecture.
All pruning certificates are exact integer identities/inequalities.
