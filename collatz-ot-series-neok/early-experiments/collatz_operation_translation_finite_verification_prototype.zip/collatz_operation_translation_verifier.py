#!/usr/bin/env python3
"""Finite Collatz verification accelerator using exact residue-cylinder translation.

Modified Collatz map:
    T(n) = n/2          if n even
           (3n+1)/2     if n odd

For fixed k and residue r mod 2^k, the first k steps have an exact affine form
    T^k(r + a 2^k) = T^k(r) + a 3^s,
where s is the number of odd steps among those k steps.

This script benchmarks:
  1) baseline exact iteration until a trajectory first drops below its start;
  2) a k-step exact cylinder certificate, with exact fallback for the remainder.

No floating-point value is used to certify descent.
"""

from __future__ import annotations
import argparse, time


def step(n: int) -> int:
    return (n >> 1) if (n & 1) == 0 else (3 * n + 1) >> 1


def iterate_k(n: int, k: int) -> tuple[int, int]:
    x, odd = n, 0
    for _ in range(k):
        if x & 1:
            odd += 1
            x = (3 * x + 1) >> 1
        else:
            x >>= 1
    return x, odd


def build_table(k: int):
    B = 1 << k
    base = [0] * B
    mul = [0] * B
    odd_count = [0] * B
    t0 = time.perf_counter()
    for r in range(B):
        m, s = iterate_k(r, k)
        base[r] = m
        odd_count[r] = s
        mul[r] = 3 ** s
    return base, mul, odd_count, time.perf_counter() - t0


def block_jump(n: int, k: int, base, mul) -> int:
    mask = (1 << k) - 1
    r = n & mask
    a = n >> k
    return base[r] + a * mul[r]


def verify_identity(k: int, base, mul, sample_residues: int = 4096) -> None:
    B = 1 << k
    stride = max(1, B // sample_residues)
    for r in range(0, B, stride):
        for a in (0, 1, 2, 7, 31):
            n = r + (a << k)
            direct, _ = iterate_k(n, k)
            jump = block_jump(n, k, base, mul)
            if direct != jump:
                raise AssertionError((r, a, direct, jump))


def baseline(limit: int):
    t0 = time.perf_counter()
    primitive_steps = 0
    for n in range(2, limit):
        x = n
        while x >= n:
            x = step(x)
            primitive_steps += 1
    return time.perf_counter() - t0, primitive_steps


def hybrid(limit: int, k: int, base, mul):
    mask = (1 << k) - 1
    t0 = time.perf_counter()
    certified = 0
    fallback = 0
    fallback_steps = 0
    for n in range(2, limit):
        r = n & mask
        a = n >> k
        y = base[r] + a * mul[r]  # exact T^k(n)
        if y < n:
            certified += 1
        else:
            fallback += 1
            x = n
            while x >= n:
                x = step(x)
                fallback_steps += 1
    return time.perf_counter() - t0, certified, fallback, fallback_steps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--exp', type=int, default=24, help='verify 1 <= n < 2^exp')
    ap.add_argument('--k', type=int, default=16, help='compiled block length')
    args = ap.parse_args()

    limit = 1 << args.exp
    base, mul, odd, build_s = build_table(args.k)
    verify_identity(args.k, base, mul)

    b_s, b_steps = baseline(limit)
    h_s, certified, fallback, f_steps = hybrid(limit, args.k, base, mul)

    print(f'domain                    : 1 <= n < 2^{args.exp} = {limit:,}')
    print(f'block length k            : {args.k}')
    print(f'table build               : {build_s:.6f} s')
    print(f'baseline time             : {b_s:.6f} s')
    print(f'baseline primitive steps  : {b_steps:,}')
    print(f'cylinder-certified        : {certified:,} / {limit-2:,} = {certified/(limit-2):.3%}')
    print(f'fallback starts           : {fallback:,}')
    print(f'fallback primitive steps  : {f_steps:,}')
    print(f'primitive-step reduction  : {1-f_steps/b_steps:.3%}')
    print(f'hybrid time (table reused): {h_s:.6f} s')
    print(f'hybrid one-shot time      : {h_s+build_s:.6f} s')
    print(f'amortized speedup         : x{b_s/h_s:.3f}')
    print(f'one-shot speedup          : x{b_s/(h_s+build_s):.3f}')


if __name__ == '__main__':
    main()
