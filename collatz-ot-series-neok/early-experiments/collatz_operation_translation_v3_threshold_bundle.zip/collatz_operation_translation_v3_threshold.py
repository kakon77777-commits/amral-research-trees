# Core V3 idea:
# Precompile each exact affine residue-class rule into a threshold.
#
# T^k(r + a*2^k) = m_r + a*3^s
#
# If 2^k > 3^s, descent holds exactly when
#   (2^k - 3^s)*a > m_r-r.
# Thus hot-loop certification becomes:
#   r = n & (2^k-1)
#   a = n >> k
#   if a >= threshold[r]: certified
#
# No log/float is used for certification.
