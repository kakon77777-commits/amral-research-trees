# Collatz Operation Translation V3 — Threshold-Compiled Certificates

The exact k-step affine rule

`T^k(r + a 2^k) = m_r + a 3^s`

is compiled once into a residue-specific integer threshold.

When `2^k > 3^s`:

`T^k(n) < n`

is equivalent to

`(2^k - 3^s) a > m_r - r`.

So the verification hot loop needs only:
- bit mask,
- bit shift,
- table lookup,
- integer comparison.

Best measured configuration at `n < 2^24`:
- k = 18
- prune ratio = 88.106%
- primitive step reduction = 64.362%
- amortized pure-Python speedup = x1.79
- one-shot speedup including table build = x1.59

This is an exact finite-range verification accelerator, not a proof of the Collatz conjecture.
