# Finite Collatz Additive-Coordinate Experiment

This bundle contains two Python MVPs:

1. `topological_log_coordinate_mvp.py`
   - Encodes nonzero reals as `(sign, k, r)` with
     `x = sign * 2^k * exp(r)`.
   - Multiplication/division become coordinate addition/subtraction.

2. `finite_collatz_additive_coordinates.py`
   - Defines the finite partial Collatz-like map on `S_N={1,...,N}`:
       - even: `n -> n/2`
       - odd:  `n -> 3n+1`, only when `3n+1 <= N`
   - In log coordinates:
       - even: `L' = L - ln(2)`
       - odd:  `L' = L + ln(3) + delta_n`
         where `delta_n = ln(1 + 1/(3n))`.
   - For finite `N`, every `delta_n` can be precomputed, so runtime
     transitions use only addition/subtraction plus table lookup.
   - With `N=100000` and 80 decimal digits:
       - valid states: 66667
       - exact integer recovery failures: 0
       - maximum absolute decode error: about 1.93e-75

Exact finite-domain recovery criterion:

If the log-coordinate error satisfies

    |epsilon_L| < ln(1 + 1/(2N)),

then nearest-integer decoding is guaranteed correct for every target in
`{1,...,N}` because the reconstructed absolute error stays below `1/2`.
