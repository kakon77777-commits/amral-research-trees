#!/usr/bin/env python3
"""
Finite Collatz-like additive-coordinate experiment.

Finite state set:
    S_N = {1,...,N}

Partial map:
    C_N(n) = n/2        if n is even
             3n + 1     if n is odd and 3n+1 <= N
             undefined  otherwise

Log coordinate L(n)=ln(n):
    even: L' = L - ln(2)
    odd:  L' = L + ln(3) + delta_n
          delta_n = ln(1 + 1/(3n))

For finite N, every odd-branch delta_n can be precomputed. Runtime then uses
only addition/subtraction plus a lookup.
"""

from dataclasses import dataclass
import mpmath as mp


@dataclass
class Result:
    N: int
    dps: int
    valid_states: int
    even_states: int
    odd_states: int
    boundary_states: int
    failures: int
    max_abs_decode_error: str
    max_log_update_error: str
    worst_n: int | None
    uniform_log_error_margin: str


def finite_collatz(n: int, N: int):
    if n % 2 == 0:
        return n // 2
    m = 3*n + 1
    return m if m <= N else None


def experiment(N: int = 100_000, dps: int = 80) -> Result:
    mp.mp.dps = dps

    ln2 = mp.log(2)
    ln3 = mp.log(3)

    # Precompute only the correction terms needed by the finite odd branch.
    delta = {
        n: mp.log1p(mp.mpf(1) / (3*n))
        for n in range(1, N + 1, 2)
        if 3*n + 1 <= N
    }

    failures = 0
    valid = even_count = odd_count = boundary = 0
    max_abs_err = mp.mpf("0")
    max_log_err = mp.mpf("0")
    worst_n = None

    # A sufficient uniform condition for exact nearest-integer recovery:
    # if |eps_L| < log(1 + 1/(2N)), then for every 1<=m<=N,
    # m*(exp(|eps_L|)-1) < 1/2.
    margin = mp.log1p(mp.mpf(1) / (2*N))

    for n in range(1, N + 1):
        target = finite_collatz(n, N)
        if target is None:
            boundary += 1
            continue

        valid += 1
        L = mp.log(n)

        if n % 2 == 0:
            even_count += 1
            Lnext = L - ln2
        else:
            odd_count += 1
            Lnext = L + ln3 + delta[n]

        Ltrue = mp.log(target)
        log_err = abs(Lnext - Ltrue)

        decoded = mp.exp(Lnext)
        abs_err = abs(decoded - target)
        recovered = int(mp.nint(decoded))

        if log_err > max_log_err:
            max_log_err = log_err
        if abs_err > max_abs_err:
            max_abs_err = abs_err
            worst_n = n

        if recovered != target or abs_err >= mp.mpf("0.5"):
            failures += 1

    return Result(
        N=N,
        dps=dps,
        valid_states=valid,
        even_states=even_count,
        odd_states=odd_count,
        boundary_states=boundary,
        failures=failures,
        max_abs_decode_error=mp.nstr(max_abs_err, 12),
        max_log_update_error=mp.nstr(max_log_err, 12),
        worst_n=worst_n,
        uniform_log_error_margin=mp.nstr(margin, 12),
    )


if __name__ == "__main__":
    r = experiment()
    print("Finite Collatz additive-coordinate experiment")
    print("=" * 72)
    print(f"N                         = {r.N}")
    print(f"decimal precision         = {r.dps}")
    print(f"valid partial-map states  = {r.valid_states}")
    print(f"  even branch             = {r.even_states}")
    print(f"  odd branch              = {r.odd_states}")
    print(f"boundary / undefined      = {r.boundary_states}")
    print(f"exact recovery failures   = {r.failures}")
    print(f"max |decode-target|       = {r.max_abs_decode_error}")
    print(f"max log-update error      = {r.max_log_update_error}")
    print(f"worst state               = {r.worst_n}")
    print(f"uniform log-error margin  = {r.uniform_log_error_margin}")
