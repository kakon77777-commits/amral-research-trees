#!/usr/bin/env python3
"""
Topological / admissible-domain logarithmic coordinate MVP

Goal
----
Represent a real number x as

    x = s * 2^k * exp(r)

with
    s in {-1, 0, +1}
    k in Z
    r in [-ln(2)/2, ln(2)/2)

Then multiplication/division become, up to normalization,

    (s1,k1,r1) * (s2,k2,r2)
        -> (s1*s2, k1+k2, r1+r2)

    (s1,k1,r1) / (s2,k2,r2)
        -> (s1*s2, k1-k2, r1-r2)

Zero is handled as a distinguished absorbing state for multiplication.
Division is a partial operation: denominator must be nonzero.

The implementation uses Decimal with guard digits so that the reconstruction
can be made arbitrarily accurate by increasing precision.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, localcontext, ROUND_HALF_EVEN, getcontext
from typing import Iterable, Tuple
import random


@dataclass(frozen=True)
class LogCoord:
    sign: int
    k: int
    r: Decimal

    @property
    def is_zero(self) -> bool:
        return self.sign == 0


class LogCoordinateSystem:
    def __init__(self, precision: int = 80, guard_digits: int = 20):
        if precision < 20:
            raise ValueError("precision should be at least 20 digits for this MVP")
        if guard_digits < 5:
            raise ValueError("guard_digits should be at least 5")
        self.precision = int(precision)
        self.guard_digits = int(guard_digits)

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            self._ln2 = Decimal(2).ln()
            self._half_ln2 = self._ln2 / Decimal(2)

    def _normalize(self, sign: int, k: int, r: Decimal) -> LogCoord:
        """
        Normalize so that r lies in [-ln(2)/2, ln(2)/2).

        Because multiplying by exp(ln 2) is the same as multiplying by 2,
        we may transfer integer multiples of ln(2) between r and k without
        changing the represented real value.
        """
        if sign == 0:
            return LogCoord(0, 0, Decimal(0))

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            ln2 = +self._ln2
            half = +self._half_ln2
            rr = +r
            kk = int(k)

            while rr >= half:
                rr -= ln2
                kk += 1

            while rr < -half:
                rr += ln2
                kk -= 1

            return LogCoord(1 if sign > 0 else -1, kk, +rr)

    def encode(self, x: Decimal | int | str) -> LogCoord:
        """
        Encode a real value into centered logarithmic coordinates.
        """
        x = Decimal(x)
        if x == 0:
            return LogCoord(0, 0, Decimal(0))

        sign = 1 if x > 0 else -1
        # copy_abs() is context-free; built-in abs(Decimal) may round
        # according to the active Decimal context before high precision begins.
        ax = x.copy_abs()

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            L = ax.ln()

            # Choose k as nearest integer to log_2(ax), which centers r near 0.
            q = L / self._ln2
            k_dec = q.to_integral_value(rounding=ROUND_HALF_EVEN)
            k = int(k_dec)
            r = L - Decimal(k) * self._ln2

            return self._normalize(sign, k, r)

    def decode(self, a: LogCoord) -> Decimal:
        """
        Reconstruct the real value.
        """
        if a.is_zero:
            return Decimal(0)

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            er = a.r.exp()

            if a.k >= 0:
                scale = Decimal(2) ** a.k
            else:
                scale = Decimal(1) / (Decimal(2) ** (-a.k))

            y = Decimal(a.sign) * scale * er

            # Round final output to the requested public precision.
            ctx.prec = self.precision
            return +y

    def multiply(self, a: LogCoord, b: LogCoord) -> LogCoord:
        """
        Total multiplication on the extended real-coordinate state space.
        """
        if a.is_zero or b.is_zero:
            return LogCoord(0, 0, Decimal(0))

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            return self._normalize(
                a.sign * b.sign,
                a.k + b.k,
                a.r + b.r,
            )

    def divide(self, a: LogCoord, b: LogCoord) -> LogCoord:
        """
        Partial division: defined iff denominator is nonzero.
        """
        if b.is_zero:
            raise ZeroDivisionError("division is undefined for denominator 0")
        if a.is_zero:
            return LogCoord(0, 0, Decimal(0))

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            return self._normalize(
                a.sign * b.sign,   # inverse of +/-1 is itself
                a.k - b.k,
                a.r - b.r,
            )

    def square(self, a: LogCoord) -> LogCoord:
        return self.multiply(a, a)

    def power_integer(self, a: LogCoord, n: int) -> LogCoord:
        """
        Integer powers become integer scaling of the logarithmic coordinates.
        """
        if n == 0:
            return self.encode(1)
        if a.is_zero:
            if n < 0:
                raise ZeroDivisionError("0 cannot be raised to a negative power")
            return LogCoord(0, 0, Decimal(0))

        if n < 0:
            inv = self.divide(self.encode(1), a)
            return self.power_integer(inv, -n)

        with localcontext() as ctx:
            ctx.prec = self.precision + self.guard_digits
            sign = 1 if (a.sign > 0 or n % 2 == 0) else -1
            return self._normalize(sign, a.k * n, a.r * Decimal(n))


def relative_error(reference: Decimal, got: Decimal, precision: int = 100) -> Decimal:
    # Error evaluation itself must also use a high-precision context.
    with localcontext() as ctx:
        ctx.prec = precision
        if reference == 0:
            return +abs(got)
        return +abs((got - reference) / reference)


def run_demo(precision: int = 80) -> None:
    sys = LogCoordinateSystem(precision=precision, guard_digits=25)

    cases = [
        ("123.456", "78.9"),
        ("-123.456", "78.9"),
        ("1e1000", "1e-700"),
        ("3.14159265358979323846264338327950288419716939937510",
         "2.71828182845904523536028747135266249775724709369995"),
        ("1e-500", "-1e400"),
        ("2", "0.5"),
    ]

    print(f"Precision = {precision} decimal digits\n")
    print("Deterministic tests")
    print("=" * 80)

    for xs, ys in cases:
        x = Decimal(xs)
        y = Decimal(ys)

        a = sys.encode(x)
        b = sys.encode(y)

        x_back = sys.decode(a)
        y_back = sys.decode(b)

        prod_coord = sys.multiply(a, b)
        prod_back = sys.decode(prod_coord)

        quot_coord = sys.divide(a, b)
        quot_back = sys.decode(quot_coord)

        with localcontext() as ctx:
            ctx.prec = precision
            prod_ref = +(x * y)
            quot_ref = +(x / y)

        print(f"x = {x}")
        print(f"y = {y}")
        print(f"enc(x) = {a}")
        print(f"enc(y) = {b}")
        print(f"encode/decode x relative error = {relative_error(x, x_back, precision + 10)}")
        print(f"encode/decode y relative error = {relative_error(y, y_back, precision + 10)}")
        print(f"x*y reconstructed = {prod_back}")
        print(f"x*y relative error = {relative_error(prod_ref, prod_back, precision + 10)}")
        print(f"x/y reconstructed = {quot_back}")
        print(f"x/y relative error = {relative_error(quot_ref, quot_back, precision + 10)}")
        print("-" * 80)

    print("\nRandom stress test")
    print("=" * 80)

    rng = random.Random(20260809)
    max_mul_err = Decimal(0)
    max_div_err = Decimal(0)
    worst_mul = None
    worst_div = None

    for _ in range(500):
        # Generate values with broad dynamic range, avoiding 0.
        mant1 = Decimal(rng.randint(1, 10**12)) / Decimal(10**6)
        mant2 = Decimal(rng.randint(1, 10**12)) / Decimal(10**6)
        exp1 = rng.randint(-300, 300)
        exp2 = rng.randint(-300, 300)
        s1 = Decimal(-1 if rng.randint(0, 1) else 1)
        s2 = Decimal(-1 if rng.randint(0, 1) else 1)

        x = s1 * mant1 * (Decimal(10) ** exp1)
        y = s2 * mant2 * (Decimal(10) ** exp2)

        a = sys.encode(x)
        b = sys.encode(y)

        got_mul = sys.decode(sys.multiply(a, b))
        got_div = sys.decode(sys.divide(a, b))

        with localcontext() as ctx:
            ctx.prec = precision
            ref_mul = +(x * y)
            ref_div = +(x / y)

        em = relative_error(ref_mul, got_mul, precision + 10)
        ed = relative_error(ref_div, got_div, precision + 10)

        if em > max_mul_err:
            max_mul_err = em
            worst_mul = (x, y, ref_mul, got_mul)
        if ed > max_div_err:
            max_div_err = ed
            worst_div = (x, y, ref_div, got_div)

    print(f"max multiplication relative error over 500 tests = {max_mul_err}")
    print(f"max division relative error over 500 tests       = {max_div_err}")

    if worst_mul:
        print("worst multiplication case:", worst_mul)
    if worst_div:
        print("worst division case:", worst_div)

    print("\nZero / admissible-domain tests")
    print("=" * 80)
    z = sys.encode(0)
    a = sys.encode("123.45")
    print("0 * 123.45 ->", sys.decode(sys.multiply(z, a)))

    try:
        sys.divide(a, z)
    except ZeroDivisionError as exc:
        print("123.45 / 0 -> correctly rejected:", exc)


if __name__ == "__main__":
    run_demo(precision=80)
